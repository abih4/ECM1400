# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification.
# 
# This module will access data from the LondonAir Application Programming Interface (API)
# The API provides access to data to monitoring stations. 
# 
# You can access the API documentation here http://api.erg.ic.ac.uk/AirQuality/help
#

def get_live_data_from_api(site_code='MY1',species_code='NO',start_date=None,end_date=None):
    """
    Return data from the LondonAir API using its AirQuality API. 
    
    *** This function is provided as an example of how to retrieve data from the API. ***
    It requires the `requests` library which needs to be installed. 
    In order to use this function you first have to install the `requests` library.
    This code is provided as-is. 
    """
    import requests
    import datetime
    start_date = datetime.date.today() if start_date is None else start_date
    end_date = start_date + datetime.timedelta(days=1) if end_date is None else end_date
    
    
    endpoint = "https://api.erg.ic.ac.uk/AirQuality/Data/SiteSpecies/SiteCode={site_code}/SpeciesCode={species_code}/StartDate={start_date}/EndDate={end_date}/Json"
   
    url = endpoint.format(
        site_code = site_code,
        species_code = species_code,
        start_date = start_date,
        end_date = end_date
    )
    
    res = requests.get(url)
    return res.json()

def get_live_data_from_api2():
    """
    Returning information about each pollutant from the API
    :param: no parameters as does not need any inputs
    :return: the data retrieved from the API
    """
    import requests    
    
    endpoint = "https://api.erg.ic.ac.uk/AirQuality/Information/Species/Json"
   
    url = endpoint.format()
        
    res = requests.get(url)
    return res.json()

def get_live_data_from_api3(site_code='MY1',start_date=None,end_date=None):
    """
    Returning all the data about all the pollutants monitored in the specified location on the specified date from the API
    :param: site_code: the location code for where to retrieve the data from
    :param: start_date: the start date for when to retrieve the data
    :param: end_date: the end date for where to stop retrieving the data
    :return: the data retrieved from the API
    """
    import requests    
    
    endpoint = "https://api.erg.ic.ac.uk/AirQuality/Data/Site/SiteCode={SiteCode}/StartDate={StartDate}/EndDate={EndDate}/Json"
   
    url = endpoint.format(
        SiteCode = site_code,
        StartDate = start_date,
        EndDate = end_date
    )
    
    res = requests.get(url)
    return res.json()



def get_pollution():
    """accessing the user input for which pollutant they wish to view
    :return: the pollution code inputted by the user"""
    print("NO - Nitric oxide")
    print("O3 - Ozone")
    print("PM10 - PM10 Particulate")
    pollution = input("Please enter the pollution you wish to see data about from the codes above: ")
    if pollution != "NO" and pollution != "O3" and pollution != "PM10":
        #If the user does not enter a valid pollutant from the list above, asking them to re-enter
        print("Invalid input - please check capitalisation and re-enter a code")
        get_pollution()
    return pollution

def highest_pollution(*args,**kwargs):
    """
    Finding the location with the highest number of times where the pollution level exceeds a certain amount
    :return: no return due to this being dealt with multiple print statements within the function
    """
    pollution = get_pollution() #calling the above function for the input
    #Using an array of dictionaries to store the locations
    location = [{"BX2": "Bexley - Belvedere ~ Suburban"}, {"BT4": "Brent - Ikea ~ Roadside"}, {"ST5": "Sutton - Beddington Lane North ~ Industrial"}, {"ST6": "Sutton-Worcester Park ~ Kerbside"}]
    #using a dictionary to store each pollutant and their maximum values before they become dangerous
    level = {"NO": 40, "O3": 5, "PM10": 54}
    #displaying to the user the locations they are monitoring
    print("Below are the locations you can monitor: ")
    print("BX2 - Bexley-Belvedere ~ Suburban")
    print("BT4 - Brent-Ikea ~ Roadside")
    if pollution == "O3":
        #O3 is not monitored in certain locations, so therefore removing these locations from the array of dictionaries
       location.pop(2)
       location.pop(2)
       #adding an additional location to compensate for removing two
       location.append({"MY1": "Marylebone Road ~ Urban Traffic"})
       print("MY1 - Maylebone Road ~ Urban Traffic")
    else:
        print("ST5 - Sutton-Beddington Lane North ~ Industrial")
        print("ST6 - Sutton-Worcester Park ~ Kerbside")
    dangerousLevels = [] #an array for storing the number of times a location exceeds the max values for each location in turn
    for i in location:
        numDangerousLevel = 0 
        data = get_live_data_from_api(str(i.keys())[12:15], pollution) #accessing the data from the API for the location currently being looked at (i)
        for j in data['RawAQData']['Data']:
            if j['@Value'] == "":
                #if there is no value for that pollutant at the specified time, will replace this with a 0
                j['@Value'] = "0"
            if float(j['@Value']) > level[pollution]:
                #if the value exceeds the dangerous value, will add one to the tally
                numDangerousLevel += 1
        dangerousLevels.append(numDangerousLevel) #adding each locations highest number of times they exceed the dangerous value on the current day
    #finding the location which has the highest number of times where their pollution exceeds a dangerous amount
    highest_level = 0
    index = 0
    highest_index = None
    for x in dangerousLevels:
        index += 1
        if x > highest_level:
            highest_level = x
            highest_index = index
    if highest_index == None:
        #if no locations have exceeded their dangerous amounts, will say this to the user
        print("No locations have exceeded the dangerous limit for " + pollution)
    else:
        highest_location = str(location[highest_index-1].values())[14:-3] #accessing the names of the locations
        areaType = highest_location.split(" ~ ") #splitting the names to allow for a more user friendly output
        #outputting to the user the most dangerous location
        print("The most dangerous location with the highest number of times the pollution level exceeds " + str(level[pollution]) +  "µg/m³ being " + str(highest_level) + " times is '" + str(areaType[0])+ "' ~ " + str(areaType[1]))
                

def get_date():
    """retrieving and returning the user input for the date they wish to see data for
    :return: the start date the user has entered"""
    import re #importing regex
    start_date = input("For Marylebone Road and the pollution, nitrogen oxide; enter the date you wish to see data from (yyyy-mm-dd): ")
    form_of_date = re.search('\d{4}[-]\d{2}[-]\d{2}', start_date) #checking to make sure the user has entered the date in the right format
    if form_of_date == None:
        #if the user has not entered the date in the right format, will ask them to re-enter
        print("Invalid date, please enter in the correct format stated")
        get_date()
    if (int(start_date[0:4]) < 1997) or (int(start_date[0:4]) == 1997 and int(start_date[5:7]) < 5) or (int(start_date[0:4]) == 1997 and int(start_date[5:7]) == 5 and int(start_date[8:10]) < 26):
        #checking the date is in the valid range for where there is data to be accessed, and if it is not, will ask them to re-enter
        print("Invalid date: please enter again (only have data from 1997-05-26 onwards): ")
        get_date()
    return start_date

def correlation(*args,**kwargs):
    """
    A graph to show the correlation of the pollution level and time on a particular day
    :return: Nothing as the image is shown on screen
    """
    from matplotlib import pyplot as mat_plot
    from datetime import datetime
    from datetime import timedelta
    start_date = get_date() #calling the above function for the input
    start_date = datetime.strptime(start_date, "%Y-%m-%d")
    end_date = start_date + timedelta(days=1) #adding one to the start date to access the end date
    data = get_live_data_from_api("MY1", "NO", str(start_date)[0:10], str(end_date)[0:10]) #retrieving the data
    #x values for the graph
    x = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"]
    #y values for the graph
    y = []
    for i in data['RawAQData']['Data']:
        if i['@Value'] == "":
            #if there is no value stored in the API will replace this with 0
            y.append(0)
        else:
            #for all data in the API, adding the y values for the data
            y.append(float(i['@Value']))
    #creating the graph graph
    mat_plot.plot(x,y) #plotting graph
    mat_plot.xlabel("Time") #naming the x axis
    mat_plot.ylabel("NO levels") #naming the y axis
    mat_plot.title("Marylebone Road - " + str(start_date)[0:10]) #giving a title to my graph
    mat_plot.show() #showing my graph to the user


def health_effects_description(data, choice, *args,**kwargs):
    """
    For a particular pollutant specified by the user, display the description of this pollutant and also the health effects
    :param: data: this is the API data retrieved before the function call
    :param: choice: the user will input their choice of pollutant to see data about
    :return: nothing to return as all been dealt with using print statements
    """
    Data = data['AirQualitySpecies']['Species']
    #if the user has entered a valid choice
    pollutant_data = Data[int(choice)-1] #accessing the data for the specified pollutant
    #the user can choose whether to see the description or health effects of the pollutant
    choice2 = input("Would you like to see the description of the pollutant (1) or the health effect of the pollutant (2)? Please enter 1 or 2: ")
    if choice2 == "1":
        #printing on screen to the user the description of the pollutant specified
        print("Description of " + pollutant_data['@SpeciesName'] + ": ")
        print(pollutant_data['@Description'])
    elif choice2 == "2":
        #printing on screen to the user the health effects of the pollutant specified
        print("The health effect of this pollutant is: ")
        print(pollutant_data['@HealthEffect'])
    else:
        #if the user has not entered 1 or 2, will ask them to re-enter
        print("Invalid input, please enter again: ")
        health_effects_description(data, choice)


def get_location():
    """retrieving and returning the location specified by the user
    :return: the location entered"""
    #printing the options of the locations and their codes
    print("VS1 - Westminster-Victoria Street")
    print("MY1 - Maylebone Road")
    location = input("Enter the location code you wish to see data from above: ")
    if location != "VS1" and location != "MY1":
        #if the user has not entered a valid code from above, will ask them to re-enter
        print("Invalid input - please check capitalisation and try again")
        get_location()
    return location

def get_startDate(location):
    """retrieving and returning the start date specified by the user
    :param: location: this is to be able to recognise which dates can be entered due to different locations being valid during different times
    :return: the start date entered"""
    import re #importing regex
    start_date = input("For " + location + ", enter the date you wish to see data from (yyyy-mm-dd): ") 
    form_of_date = re.search('\d{4}[-]\d{2}[-]\d{2}', start_date) #checking to make sure the user has entered the date in the right format
    if form_of_date == None:
        #if the user has not entered the date in the correct format, will ask them to re-enter
        print("Invalid date, please enter in the correct format stated")
        get_date()
    if location == "VS1":
        #for Victoria Street, the date is only valid between 2003-05-02 and 2008-04-01, so checking this against the input from the user
        if (int(start_date[0:4]) < 2003) or (int(start_date[0:4]) == 2003 and int(start_date[5:7]) < 5) or (int(start_date[0:4]) == 2003 and int(start_date[5:7]) == 5 and int(start_date[8:10]) < 2):
            #if the date is outside of this range, will ask to re-enter
            print("Invalid date: please enter again (only have data from 2003-05-02 onwards): ")
            get_startDate(location)
        elif (int(start_date[0:4]) > 2008) or (int(start_date[0:4]) == 2008 and int(start_date[5:7]) > 4) or (int(start_date[0:4]) == 2008 and int(start_date[5:7]) == 4 and int(start_date[8:10]) > 1):
            #if the date is outside of this range, will ask to re-enter
            print("Invalid date: please enter again (only have data from before 2008-04-01: ")
            get_startDate(location)
    elif location == "MY1":
        #for Marylebone Road, the date is valid from 1997-05-26 onwards, so checking this against the input from the user
        if (int(start_date[0:4]) < 1997) or (int(start_date[0:4]) == 1997 and int(start_date[5:7]) < 5) or (int(start_date[0:4]) == 1997 and int(start_date[5:7]) == 5 and int(start_date[8:10]) < 26):
            #if the date is outside of this range, will ask to re-enter
            print("Invalid date: please enter again (only have data from 1997-05-26 onwards): ")
            get_startDate(location)
    return start_date

def bar_chart(*args,**kwargs):
    """
    Creating a var chart to display the value for all the different pollutants in a particular location at a specified time
    :return: nothing as the bar chart is shown
    """
    import matplotlib.pyplot as mat_plot
    from datetime import datetime
    from datetime import timedelta
    location = get_location() #retrieving the location from above
    start_date = get_startDate(location) #retrieving the start date from above
    start_date = datetime.strptime(start_date, "%Y-%m-%d")
    end_date = start_date + timedelta(days=1) #adding one to the start date to access the end date
    data = get_live_data_from_api3(location, str(start_date)[0:10], str(end_date)[0:10]) #accessing the data from the API
    #creating the bar chart
    left = [] #empty array for the x-coordinates of the left sides of each bar
    height = [] #empty array for the heights of each bar
    bar_label = [] #empty array for the names of each bar
    index = 1 #to calculate the x-coordinates for the left sides of each bar
    for i in data['AirQualityData']['Data']:
        if str(i['@MeasurementDateGMT'])[11:13] == '12': #using the data at 12:00pm for the specified day
            left.append(index) #for every data itemm, adding the next x-coordinate
            bar_label.append(str(i['@SpeciesCode'])) #adding the bar label for the data currently looking at
            if i['@Value'] == "":
                #if no data values exist, replacing with a 0
                height.append(0)
            else:
                #adding the data values for the pollutant to height
                height.append(float(i['@Value']))
            index += 1
    #plotting the bar chart
    mat_plot.bar(left, height, tick_label = bar_label, width = 0.8, color = ['red', 'green']) #plotting the data items from above
    mat_plot.xlabel("Pollutants") #naming the x-axis
    mat_plot.ylabel("Pollutant levels") #naming the y-axis
    mat_plot.title("Pollutant levels in " + location + " on " + str(start_date)[0:10]) #giving a title to my bar chart
    mat_plot.show() #function to show the bar chart