# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification
import sys
import csv 
import numpy as np
from matplotlib import pyplot as mat_plot

def read_data(monitoring_station):
    """Reading the data from the files
    :param: monitoring_station: the location that the user has specified they want to see data for
    :return: csvReader: the array of dictionaries containing the data reqired"""
    csvreader = {}
    path = './data/' #finding the folder for where the data is stored
    if monitoring_station == "Harlington":
        with open(path + 'Pollution-London Harlington.csv', 'r') as file:
            csvreader = csv.DictReader(file) #reading file into a dictionary
            csvReader = list(csvreader) #creating a list of dictionaries
        return csvReader #returning the data
    elif monitoring_station == "Marylebone Road":
        with open(path + 'Pollution-London Marylebone Road.csv', 'r') as file:
            csvreader = csv.DictReader(file) #reading file into a dictionary
            csvReader = list(csvreader) #creating a list of dictionaries
        return csvReader #returning the data
    elif monitoring_station == "N. Kensington":
        with open(path + 'Pollution-London N Kensington.csv', 'r') as file:
            csvreader = csv.DictReader(file) #reading file into a dictionary
            csvReader = list(csvreader) #creating a list of dictionaries
        return csvReader #returning the data


def main_menu():
    """
    Presenting the main menu to the user, and allows input from the user to navigate
    :return: no return as it simply opens other functions
    """
    #printing all the options of the main menu on screen to the user
    print("R - Access the PR module")
    print("I - Access the MI module")
    print("M - Access the RM module")
    print("A - Print the About text")
    print("Q - Quit the application")
    #allowing the user to input their request of what they would like to do
    choice = input("Enter the corresponding letter of what you would like to do: ")
    if choice == "R":
        #if the user enters 'R', it means they want to access the reporting menu
        reporting_menu()
    elif choice == "I":
        #if the user enters 'I', it means they want to access the intelligence menu
        intelligence_menu()
    elif choice == "M":
        #if the user enters 'M', it means they want to access the monitoring menu
        monitoring_menu()
    elif choice == "A":
        #if the user enters 'A', it means they want to see about
        about()
    elif choice == "Q":
        #if the user enters 'Q', it means they want to quit the program
        quit()
    else:
        #if the user does not enter a valid input above, will allow them to re-enter
        print("Invalid input - please try again")
        main_menu()


def get_location():
    """Retrieving and returning the location specified by the user
    :return: location: the user has entered the location they wish to see data about"""
    #printing the monitoring stations below for the user to choose
    print("Below are the different monitoring locations:")
    print("1. Harlington")
    print("2. Marylebone Road")
    print("3. N. Kensington")
    #asking the user to enter the location they would like to see data from
    location = input("Please enter the number of the monitoring station you would like to see data about: ")
    #converting the numbers to the location names for use later in the program
    if location == '1':
        location = "Harlington"
    elif location == '2': 
        location = "Marylebone Road"
    elif location == '3':
        location = "N. Kensington"
    else:
        #if the location entered is not a valid location, asking the user to re-enter
        print("Invalid input. Please enter an option from above (beware of capitals and punctuation), please re-enter: ")
        get_location()
    return location

def get_pollutant():
    """Retrieving and returning the pollutant specified by the user
    :return: pollutant: the user has entered the pollutant they wish to see data about"""
    #printing the pollutants below for the user to choose
    print("Below are the three different pollutants: ")
    print("Nitric oxide (no)")
    print("PM10 inhalable particulate matter (pm10)")
    print("PM2.5 inhalable particulate matter (pm25)")
    #asking the user to enter the pollutant they would like to see data about
    pollutant = input("Please enter the letters/numbers in brackets above for the pollutant you want to see data about: ")
    if pollutant != "no" and pollutant != "pm10" and pollutant != "pm25":
        #if the pollutant entered is not a valid pollutant, asking the user to re-enter the data above
        print("Invalid input. Please enter an option from above (beware of capitals), please re-enter the location and pollutant: ")
        get_pollutant()
    return pollutant

def reporting_menu():
    """
    Runs when option R is chosen. Allows the user to navigate through the reporting menu
    :return: no return as it is used to run other functions
    """
    import reporting
    location = get_location() #accessing the location specified by the user in the function above
    pollutant = get_pollutant() #accessing the pollutant specified by the user in the function above
    #printing the options the user can access
    print("Below are the different data collections you can view:")
    print("DA - daily average")
    print("DM - daily median")
    print("HA - hourly average")
    print("MA - monthly average")
    print("PH - peak hour")
    #asking the user to enter what they would like to see
    choice = input("Enter the corresponding letter of what you would like to see: ")
    #need to access the data again, as after it has been used once, the variable is empty
    Data = read_data(location) #accessing the dictionary of data for the location specified
    if choice == "DA":
        #if the user enters 'DA", will display the daily average of the data
        print(reporting.daily_average(Data, location, pollutant))
    elif choice == "DM":
        #if the user enters 'DM", will display the daily median of the data
        print(reporting.daily_median(Data, location, pollutant))
    elif choice == "HA":
        #if the user enters 'HA', will display the hourly average of the data
        print(reporting.hourly_average(Data, location, pollutant))
    elif choice == "MA":
        #if the user enters 'MA', will display the monthly average of the data
        print(reporting.monthly_average(Data, location, pollutant))
    elif choice == "PH":
        #asking the user to enter the date they want to see data about in the right format
        date = input("Enter the date you wish to see the peak hour of pollution (YYYY-MM-DD): ")
        #if the user enters 'PH', will display the peak hour of the data
        print(reporting.peak_hour_date(Data, date, location, pollutant))
    else:
        #if none of the above are entered, will ask for another input
        print("Invalid input, please try again: ")
        reporting_menu()
    main_menu() #reopening the main menu ready for another choice


def get_choice():
    """Retrieving and returning the choice of pollutant specified by the user
    :return: choice: The number specified by the user for the pollutant they wish to see information about"""
    #Displaying the user the possible pollutants to see information about
    print("Below are the pollutants for you to choose from: ")
    print("1. CO - Carbon Monoxide")
    print("2. NO2 - Nitrogen Dioxide")
    print("3. O3 - Ozone")
    print("4. PM10 - PM10 Particulate")
    print("5. PM25 - PM2.5 Particulate")
    print("6. SO2 - Sulphur Dioxide")
    #asking the user to enter the number of their choice of pollutant
    choice = input("Please enter the number of the pollutant you wish to see information about: ")
    if choice != "1" and choice != "2" and choice != "3" and choice != "4" and choice != "5" and choice != "6":
        #if the user has not entered a valid choice for pollutant, will ask them to re-enter
        print("Invalid choice, please enter again: ")
        get_choice()
    return choice

def monitoring_menu():
    """
    Runs when option M is chosen. Allows the user to navigate through real-time monitoring
    :return: no return as it is used to call other functions
    """
    import monitoring
    #printing all the options for what the user can access, with a number to make it easier for the user to enter what they would like to see
    print("Below are the options for what you can do: ")
    print("1. Find out the most dangerous location based on the pollution levels today")
    print("2. See a graph showing the correlation between pollution levels and time on a specified day")
    print("3. Show the description and the health effects of a specified pollutant")
    print("4. See a bar chart containing different pollutants and their values on a specified day and location")
    #asking the user to enter the number for the preferred thing they would like to access
    task = input("Please enter the number of the task you would like to view: ")
    if task == "1":
        #if the user chooses option 1, will print the most dangerous location based on the pollution levels today
        monitoring.highest_pollution()
    elif task == "2":
        #if the user chooses option 2, will display a graph showing the correlation between pollution levels and time on a specified day
        monitoring.correlation()
    elif task == "3":
        #if the user chooses option 3, will show a description and health effects of a specified pollutant
        choice = get_choice()
        monitoring.health_effects_description(monitoring.get_live_data_from_api2(), choice)
    elif task == "4":
        #if the user chooses option 4, will display a bar chart containing different pollutants on a specified day and location
        monitoring.bar_chart()
    else:
        #if the user does not enter a valid input above, will allow them to re-enter, by recursively calling the function
        print("Invalid input, ensure you enter a number 1-4: please try again: ")
        monitoring_menu()
    main_menu()


def intelligence_menu():
    """
    Runs when option I is chosen. Allows the user to navigate through the mobility intelligence menu
    :return: no return as it is used to run other functions
    """
    import intelligence
    #printing all the options for what the user can access, with a number to make it easier for the user to enter what they would like to see
    print("Below are the options for what you can see: ")
    print("1. View the image of the Marylebone Road area map")
    print("2. View the image of red pixels for the Marylebone Road area")
    print("3. View the image of cyan pixels for the Marylebone Road area")
    print("4. View the list of all connected components within the Marylebone Road area map")
    print("5. View the image of the top two largest connected components")
    #asking the user to enter the number for the preferred thing they would like to access
    choice = input("Please enter the number of the task you would like to view: ")
    if choice == "1":
        #if the user chooses option 1, will show the image of the Marylebone Road area map
        path = './data/'
        image = mat_plot.imread(path + 'map.png')
        mat_plot.imshow(image)
        mat_plot.show()
    elif choice == "2":
        #if the user chooses option 2, will show the image of the red pixels 
        image = intelligence.find_red_pixels('map.png')
        mat_plot.imshow(image)
        mat_plot.show()
    elif choice == "3":
        #if the user chooses option 3, will show the image of the cyan pixels 
        image = intelligence.find_cyan_pixels('map.png')
        mat_plot.imshow(image)
        mat_plot.show()
    elif choice == "4":
        #if the user chooses option 4, will print all the connected components in sorted order from the biggest to the smallest
        cc = intelligence.detect_connected_components(intelligence.find_red_pixels('map.png'))
        with open('cc-output-2b.txt', 'r') as file:
            for line in file:
                line.strip()
                print(line)
    elif choice == "5":
        #if the user chooses option 5, will show the image of the top two largest connected components
        cc = intelligence.detect_connected_components(intelligence.find_red_pixels('map.png'))
        intelligence.detect_connected_components_sorted(cc)
        image = mat_plot.imread('cc-top-2.jpg')
        mat_plot.imshow(image)
        mat_plot.show()
    else:
        #if the user does not enter a valid input above, will allow them to re-enter, by recursively calling the function
        print("Invalid input, ensure you enter a number 1-5: please try again: ")
        intelligence_menu()
    main_menu()


def about():
    """
    Prints a string containing the module code, and a string with candidate number
    :return: no return as all done through print statements
    """
    print("The module code is: ECM1400") #prints the module code
    print("Candidate number is: 230676") #prints my candidate number
    main_menu() #returns back to the main menu ready for another choice


def quit():
    """
    Quits the overall program
    """
    sys.exit() #quits the whole program




if __name__ == '__main__':
    main_menu()
