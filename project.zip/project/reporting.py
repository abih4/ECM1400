# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification
import numpy as np

def missing_data(location, pollutant):
    """To deal with missing data, asking the user to input a preferred value
    :param: location: the location that the user has entered to specify which monitoring station to look at
    :param: pollutant: the pollutant that the user has entered to specify which pollutant to look at
    :return: value: the replacement value the user has entered for any missing data values"""
    import main
    Data = main.read_data(location) #accessing the dictionary of data for the location specified
    print("To deal with missing data: ")
    missingData = count_missing_data(Data, location, pollutant) #calculating the number of missing data entries
    print("The number of 'no data' entries for the " + str(pollutant) + " pollutant in " + str(location) + " is " + str(missingData)) #displaying number of missing data entries to the user
    #asking the user how to deal with these missing data values - to enter a value to replace them with
    value = input("How would you like to deal with these missing entries? Please enter the number to replace them with: ") 
    if value.isnumeric == False:
        #if the value entered is not an integer, asks the user to re-enter their value
        print("Invalid input, please enter an integer. Please try again: ")
        missing_data(location, pollutant)
    #need to access the data again, as after it has been used once, the variable is empty
    Data = main.read_data(location) #accessing the dictionary of data for the location specified
    replacementData = fill_missing_data(Data, value, location, pollutant) #replacing the missing data with value specified above by the user
    print("Below is an array of dictionaries for the replaced missing data: ")
    print(replacementData) #displaying the changed data to the user
    return value #returning the replacement value for missing data, for use in the functions below

def daily_average(data, montoring_station, pollutant):
    """
    Calculates the daily averages for a particular pollutant and monitoring station
    :param: data: the dictionary containing all the data for the location specified in the main menu
    :param: monitoring_station: the location that the user has specified in the main menu
    :param: pollutant: the pollutant that the user has specified in the main menu
    :return: roundDailyAverages: an array containing 365 daily averages for the pollutant and location specified
    """
    location = montoring_station
    dailyAverages = [] #the empty array which will be returned at the end of the function containing 365 daily averages
    total = 0 #initialising a variable to store the total pollutant for each day
    index = 0 #for counting number of hours that have passed to allow for the total to restart on the next day
    replacement_value = missing_data(location, pollutant) #dealing with any missing data values should they arise
    for row in data:
        #iterating through every row of the data
        pollution = row[pollutant] #accessing the pollutant data for that particular day and hour
        if pollution == 'No data':
            #for all 'No data' values, replacing them with the replacement value specified by the user above in missing_data()
            pollution = replacement_value
        total = total + float(pollution) #adding to the total the pollution value
        index +=1 #adding 1 to the hour tally
        if index == 24: #as soon as index reaches 24, means the day is over, and so needs to be reset
            average = total/24 #working out the average for that day
            dailyAverages.append(average) #storing the average in the array to be returned
            total = 0 #resetting the total to 0
            index = 0 #resetting the index for the hour back to 0
    roundDailyAverages = [round(item, 3) for item in dailyAverages] #rounding the averages to 3 decimal places to be more user-friendly
    return roundDailyAverages #returning the array

def daily_median(data, monitoring_station, pollutant):
    """
    Calculates the daily median values for a particular pollutant and monitoring station
    :param: data: the dictionary containing all the data for the location specified in the main menu
    :param: monitoring_station: the location that the user has specified in the main menu
    :param: pollutant: the pollutant that the user has specified in the main menu
    :return: roundDailyMedians: an array containing 265 daily medians for the pollutant and location specified
    """
    location = monitoring_station
    dailyMedians = [] #the empty array which will be returned at the end of the function containing 365 daily medians
    daily = [] #initialising an array to store all the pollutant values for a particular day
    index = 0 #for counting number of hours that have passed to allow for the total to restart on the next day
    replacement_value = missing_data(location, pollutant) #dealing with any missing data values should they arise
    for row in data:
        #iterating through every row of the data
        pollution = row[pollutant] #accessing the pollutant data for that particular day and hour
        if pollution == 'No data':
            #for all 'No data' values, replacing them with the replacement value specified by the user above in missing_data()
            pollution = replacement_value
        daily.append(float(pollution)) #adding the data for that particular day and hour to the array to be able to do the calculation
        index += 1 #adding 1 to the hour tally
        if index == 24: #as soon as index reaches 24, means the day is over, and so needs to be reset
            npdaily = np.array(daily) #converting the daily array to a numpy array
            median = np.median(npdaily) #calculating the median of the data
            dailyMedians.append(median) #storing the median in the array to be returned
            daily = [] #resetting the daily array to be empty for a new day
            index = 0 #resetting the index or the hour back to 0
    roundDailyMedians = [round(item, 3) for item in dailyMedians] #rounding the medians to 3 decimal places to be more user-friendly
    return roundDailyMedians #returning the array
        
def hourly_average(data, monitoring_station, pollutant):
    """
    Calculates the hourly averages for a particular pollutant and monitoring station
    :param: data: the dictionary containing all the data for the location specified in the main menu
    :param: monitoring_station: the location that the user has specified in the main menu
    :param: pollutant: the pollutant that the user has specified in the main menu
    :return: roundHourlyAverage: an array containing 24 hourly averages for the pollutant and location specified
    """
    location = monitoring_station
    hourlyAverage = [] #the empty array which will be returned at the end of the function containing 24 hourly averages
    hours = {} #initialising a dictionary to store the pollutant values for every hour on different days
    hour = [] #initialising an array to store a set of pollutant values for a particular hour to be able to work out the average
    replacement_value = missing_data(location, pollutant) #dealing with any missing data values should they arise
    #creating a dictionary with all the data for each hour
    for row in data:
        #iterating through every row of the data
        pollution = row[pollutant] #accessing the pollutant data for that particular day and hour
        if pollution == 'No data':
            #for all 'No data' values, replacing them with the replacement value specified by the user above in missing_data()
            pollution = replacement_value
        if row['time'] in hours:
            #if the hour currently being looked at already exists in the dictionary, just adding the pollutant value to the array value
            hours[row['time']].append(float(pollution))
        else:
            #if the hour currently being looked at does not already exist in the dictionary, creating a new key value pair
            hours[row['time']] = [float(pollution)] #value is an array
    #using the dictionary to find the hourly averages for each value
    for key in hours:
        #iterating through every key value pair in the dictionary
        for value in hours[key]:
            #for every value in the array of the key value pair, adding it to the new array 'hour' to work out the hourly average
            hour.append(value)
        nphour = np.array(hour) #converting the hour array to a numpy array
        average = np.average(nphour) #calculating the average of the data
        hourlyAverage.append(average) #storing this average in the array to be returned
        hour = [] #resetting the hour array to be empty for the next set of hour datas
    roundHourlyAverage = [round(item, 3) for item in hourlyAverage] #rounding the averages to 3 decimal places to be more user-friendly
    return roundHourlyAverage #returning the array

def monthly_average(data, monitoring_station, pollutant):
    """
    Calculates the monthly averages for a particular pollutant and monitoring station
    :param: data: the dictionary containing all the data for the location specified in the main menu
    :param: monitoring_station: the location that the user has specified in the main menu
    :param: pollutant: the pollutant that the user has specified in the main menu
    :return: roundMonthlyAverage: an array containing 12 monthly averages for the pollutant and location specified
    """
    location = monitoring_station
    monthlyAverage = [] #the empty array which will be returned at the end of the function containing 12 monthly averages
    months = {} #initialising a dictionary to store the pollutant values for every month on different days and at different times
    monthData = [] #initialising an array to store a set of pollutant values for a particular month to be able to work out the average
    replacement_value = missing_data(location, pollutant) #dealing with any missing data values should they arise
    #creating a dictionary with all the data for each month
    for row in data:
        #iterating through every row of the data
        pollution = row[pollutant] #accessing the pollutant for that particular day and hour
        if pollution == 'No data':
            #for all 'No data' values, replacing them with the replacement value specified by the user above in missing_data()
            pollution = replacement_value
        month = row['date'] #accessing the date for the current row being looked at
        if month[5:7] in months: #5:7 is the index for the month section of the date
            #if the current month being looked at already exists in the dictionary, just adding the pollutant value to the array value
            months[month[5:7]].append(float(pollution))
        else:
            #if the current month being looked at does not already exist in the dictionary, creating a new key value pair
            months[month[5:7]] = [float(pollution)]
    #using the dictionary to find the monthly averages for every value
    for key in months:
        #iterating through every key value pair in the dictionary
        for value in months[key]:
            #for every value in the array of the key value pair, adding it to the new array 'monthData' to work out the monthly average
            monthData.append(value)
        npMonthData = np.array(monthData) #converting the monthData array to a numpy array
        average = np.average(npMonthData) #calculating the average of the data
        monthlyAverage.append(average) #storing this average in the array to be returned
        monthData = [] #resetting the monthData array to be empty for the next set of month datas
    roundMonthlyAverage = [round(item, 3) for item in monthlyAverage] #rounding the averages to 3 decimal places to be more user-friendly
    return roundMonthlyAverage #returning the array

def peak_hour_date(data, date, monitoring_station,pollutant):
    """
    For a particular date, calculates the hour of the day with the highest pollution level, and this highest value
    :param: data: the dictionary containing all the data for the location specified in the main menu
    :param: date: the date spepcified by the user in the main menu for which day to look at
    :param: monitoring_station: the location that the user has specified in the main menu
    :param: pollutant: the pollutant that the user has specified in the main menu
    :return: highestHour: the time at which the pollution is at its highest for the specified day, location and pollutant
    :return: highestPollution: the highest pollution value for the specified day, location and pollutant
    """
    location = monitoring_station
    day = [] #initialising an array to store the pollutant values for the date specified
    hour = 1 #setting the intial hour to be 1, which will be incremented as you look through all the values in the array 'day'
    highestPollution = 0 #initialising a variable to store the highest pollution value, to be returned at the end of the function
    highestHour = 0 #initialising a variable to store the hour with the highest pollution value, to be returned at the end of the function
    replacement_value = missing_data(location, pollutant) #dealing with any missing data values should they arise
    #to create an array with all the data needed to work out the peak hour
    for row in data:
        #iterating through every row of the data
        pollution = row[pollutant] #accessing the pollutant for that particular day and hour
        if pollution == 'No data':
            #for all 'No data' values, replacing them with the replacement value specified by the user above in missing_data()
            pollution = replacement_value
        if row['date'] == date:
            #if the row currently being looked at has the same date as the data we need, adds the pollution value to the 'day' array
            day.append(float(pollution))
    #iterating through the data gathered above to produce the peak hour
    for item in day:
        if hour == 1 or item > highestPollution:
            #if it is the first hour, or if the current pollution value is higher than the highest pollution value currently stored
            #adds/replaces the pollution value in highestPollution, and stores the hour in highestHour
            highestPollution = item
            highestHour = hour
        hour += 1 #adding 1 to the hour tally
    highestHour = str(highestHour) + ":00" #putting the hour into the correct format
    return highestHour, highestPollution #returning the hour and pollution values

def count_missing_data(data,  monitoring_station,pollutant):
    """
    Calculates the number of no data entries for a given pollutant and monitoring station
    :param: data: the dictionary containing all the data for the location specified in the main menu
    :param: monitoring_station: the location that the user has specified in the main menu
    :param: pollutant: the pollutant that the user has specified in the main menu
    :return: noDataEntries: an integer representing the number of no data entries for the specified location and pollutant
    """
    noDataEntries = 0 #initialising a variable to store the number of no data entries
    for row in data:
        #iterating through every row of the data
        if row[pollutant] == 'No data':
            #if the pollutant value is 'No data', adding 1 to the tally of no data entries
            noDataEntries += 1
    return noDataEntries #returning the number of no data entries

def fill_missing_data(data, new_value,  monitoring_station,pollutant):
    """
    Creates a copy of data with the missing values 'No data' replaced by new_value for a given pollutant and monitoring station
    :param: data: the dictionary containing all the data for the location specified in the main menu
    :param: new_value: the replacement value specified by the user to fill the missing data values
    :param: monitoring_station: the location that the user has specified in the main menu
    :param: pollutant: the pollutant that the user has specified in the main menu
    :return: newData: an array of dictionaries, containing the No data values replaced with new_value for the specified location and pollutant
    """
    newData = [] #initialising an array to store the rows of data that are being replaces
    for row in data:
        #iterating through every row of the data
        if row[pollutant] == 'No data':
            #if the pollutant value is 'No data', replacing the value with the new_value
            row[pollutant] = new_value
            newData.append(row) #adding the row to the array to be returned as there has been a change
    return newData #returning the array of new data

