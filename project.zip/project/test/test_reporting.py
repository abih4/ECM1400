import pytest
import csv
import reporting

##Within the test directory, so does not work, but outside of this they should##

##None of these tests work due to these functions taking in inputs, and pytest cannot use user inputs##
##If you remove the inputs of the functions, all these tests pass##

def test_MissingData():
    assert reporting.missing_data("Harlington", "pm25") == 1

def test_DailyAverage():
    csvreader = {}
    path = './data/'
    #checking function finds the daily average correctly
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert reporting.daily_average(csvreader, "Harlington", "pm25")[0] == 18.271
    file.close()
    #checking function works for a different location
    file = open(path + 'Pollution-London Marylebone Road.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert reporting.daily_average(csvreader, "Marylebone Road", "no")[1] == 11.244
    file.close()
    #checking function works when there is No Data, uses the replacement data
    file = open(path + 'Pollution-London N Kensington.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert reporting.daily_average(csvreader, "N Kensington", "no")[33] == 1.344
    file.close()
    #checking the function returns 365 values
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert len(reporting.daily_average(csvreader, "Harlington", "pm25")) == 365
    file.close()
    #the erroneous inputs to the functions is handled in the main menu

def test_DailyMedian():
    csvreader = {}
    path = './data/'   
    #checking function finds the daily median correctly
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert reporting.daily_median(csvreader, "Harlington", "pm25")[0] == 19.242
    file.close()
    #checking function works for a different location
    file = open(path + 'Pollution-London Marylebone Road.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert reporting.daily_median(csvreader, "Marylebone Road", "no")[1] == 11.042
    file.close()
    #checking function works when there is No Data, uses the replacement data
    file = open(path + 'Pollution-London N Kensington.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert reporting.daily_median(csvreader, "N Kensington", "no")[33] == 1
    file.close()
    #checking the function returns 365 values
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert len(reporting.daily_median(csvreader, "Harlington", "pm25")) == 365
    file.close()
    #the erroneous inputs to the functions is handled in the main menu

def test_HourlyAverage():
    csvreader = {}
    path = './data/'   
    #checking function finds the hourly average correctly
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for the first 5 days(5x24=120)
    assert reporting.hourly_average(csvReader[0:120:], "Harlington", "pm25")[0] == 9.059
    file.close()
    #checking function works for a different location
    file = open(path + 'Pollution-London Marylebone Road.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for the first 5 days (5x24=120)
    assert reporting.hourly_average(csvReader[0:120], "Marylebone Road", "no")[1] == 3.101
    file.close()
    #checking function works when there is No Data, uses the replacement data
    file = open(path + 'Pollution-London N Kensington.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing between 2/2/21 (32x24=768) and 7/2/21 (37x24=888)
    assert reporting.hourly_average(csvReader[768:888], "N Kensington", "no")[11] == 2.719
    file.close()
    #checking the function returns 24 values
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert len(reporting.hourly_average(csvreader, "Harlington", "pm25")) == 24
    file.close()
    #the erroneous inputs to the functions is handled in the main menu

def test_MonthlyAverage():
    #to test the monthly average, I will create data for two days of the month, as this is a simpler version of calculating for a whole month
    csvreader = {}
    path = './data/'   
    #checking function finds the monthly average correctly
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for the first 2 days(2x24=48)
    assert reporting.monthly_average(csvReader[0:48], "Harlington", "pm25")[0] == 12.214
    file.close()
    #checking function works for a different location
    file = open(path + 'Pollution-London Marylebone Road.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for the first 2 days (2x24=48)
    assert reporting.monthly_average(csvReader[0:48], "Marylebone Road", "pm10")[0] == 16.377
    file.close()
    #checking function works when there is No Data, uses the replacement data
    file = open(path + 'Pollution-London N Kensington.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing between 2/2/21 (32x24=768) and 3/2/21 (33x24=792)
    assert reporting.monthly_average(csvReader[768:792], "N Kensington", "no")[0] == 3.215
    file.close()
    #checking the function returns 12 values
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    assert len(reporting.monthly_average(csvreader, "Harlington", "pm25")) == 12
    file.close()
    #the erroneous inputs to the functions is handled in the main menu

def test_PeakHourDate():
    csvreader = {}
    path = './data/'   
    #checking function finds the monthly average correctly
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for the first day
    assert reporting.peak_hour_date(csvReader, "2021-01-01", "Harlington", "pm25")[0] == "14:00", 27.694
    file.close()
    #checking function works for a different location
    file = open(path + 'Pollution-London Marylebone Road.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for the first day
    assert reporting.peak_hour_date(csvReader, "2021-01-01", "Marylebone Road", "pm10")[0] == "2:00", 45.1
    file.close()
    #checking function works when there is No Data, uses the replacement data
    file = open(path + 'Pollution-London N Kensington.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing on 2.2.2021
    assert reporting.peak_hour_date(csvReader[32::], "2021-02-02", "N Kensington", "no")[0] == "9:00", 19.80245
    file.close()
    #the erroneous inputs to the functions is handled in the main menu

def test_CountMissingData():
    csvreader = {}
    path = './data/'   
    #checking function calculates the number of missing data for Harlington
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for the whole of February (31x24=744, 59x24=1416)
    assert reporting.count_missing_data(csvReader[744:1416], "Harlington", "pm25") == 28
    file.close()
    #checking function works for a different location - Marylebone Road
    file = open(path + 'Pollution-London Marylebone Road.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for the whole of February (31x24=744, 59x24=1416)
    assert reporting.count_missing_data(csvReader[744:1416], "Marylebone Road", "pm10") == 6
    file.close()
    #checking function works for the final location - N Kensington
    file = open(path + 'Pollution-London N Kensington.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for the whole of February (31x24=744, 59x24=1416)
    assert reporting.count_missing_data(csvReader[744:1416], "N Kensington", "no") == 37
    file.close()
    #the erroneous inputs to the functions is handled in the main menu

def test_FillMissingData():
    csvreader = {}
    path = './data/'   
    #checking function calculates the number of missing data for Harlington
    file = open(path + 'Pollution-London Harlington.csv', 'r') 
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for one day in February that has missing data - 3.2.2021 (33x24=792)
    assert reporting.fill_missing_data(csvReader[792:816], "1", "Harlington", "pm25")[0] == {'date': '2021-02-03', 'time': '01:00:00', 'no': 'No data', 'pm10': 'No data', 'pm25': '1'}
    file.close()
    #checking function returns the correct number of rows for the number of missing data to fill
    file = open(path + 'Pollution-London Marylebone Road.csv', 'r')
    csvreader = csv.DictReader(file) #reading file into a dictionary
    csvReader = list(csvreader)
    #testing for one day in January that has missing data = 26.1.2021 (25x24=600)
    assert len(reporting.fill_missing_data(csvReader[600:624], "1", "Marylebone Road", "pm10")) == 14
    file.close()
    #the erroneous inputs to the functions is handled in the main menu


#if __name__ == '__main__':    
    #pytest test_reporting.py

