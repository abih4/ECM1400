import utils
import pytest

##Within the test directory, so does not work, but outside of this they should##

def test_sumValues():
    #testing with a list of integers
    assert utils.sumvalues([1, 2, 3, 4]) == 10
    #testing with an empty list
    assert utils.sumvalues([]) == 0
    #testing when should produce an error - contains string
    with pytest.raises(TypeError):
        utils.sumvalues([1, 2, 'q', 3])

def test_maxValue():
    #testing with a list of integers
    assert utils.maxvalue([3, 4, 7, 2]) == 2
    #testing with an empty list
    assert utils.maxvalue([]) == None
    #testing when should produce an error - contains string
    with pytest.raises(TypeError):
        utils.maxvalue([1, 5, 'q', 4])

def test_minValue():
    #testing with a list of integers
    assert utils.minvalue([3, 4, 7, 2]) == 3
    #testing with an empty list
    assert utils.minvalue([]) == None
    #testing when should produce an error - contains string
    with pytest.raises(TypeError):
        utils.minvalue([1, 5, 'q', 4])

def test_meanValue():
    #testing with a list of integers
    assert utils.meannvalue([3, 4, 7, 2]) == 4
    #testing with an empty list
    assert utils.meannvalue([]) == None
    #testing when should produce an error - contains string
    with pytest.raises(TypeError):
        utils.meannvalue([1, 5, 'q', 4])

def test_countValue():
    #testing with only one appearance
    assert utils.countvalue([1, 2, 3, 4], 4) == 1
    #testing with multiple appearances
    assert utils.countvalue([1, 1, 3, 4], 1) == 2
    #testing with no appearances
    assert utils.countvalue([1, 2, 3 ,4], 'q') == 0