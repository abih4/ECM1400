# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification
import numpy as np
from matplotlib import pyplot as mat_plot

def find_red_pixels(map_filename, upper_threshold = 100, lower_threshold = 50, *args,**kwargs):
    """
    Returns numpy array representing the binary image, and saves the image for the red pixels in a jpg file
    :param: map_filename: the filename of the image we want to access
    :param: upper_threshold=100: this is set at 100 unless specified otherwise, used to determine the rgb values
    :param: lower_threshold=50: this is set at 100 unless specified otherwise, used to determine the rgb values
    :return: output_image: binary 2D numpy array of the red pixels found
    """
    output_image = np.array #initialising the numpy array to store the output image
    path = './data/' #accessing the path to be able to retrive the map image
    image = mat_plot.imread(path + map_filename) #reading in the image data
    output_image = np.empty([1140, 1053]) #initialising the size of the output array to be the same size as the image data array - the image is [1140. 1053, 4] but do not need opaqueness and rgb in a binary image so no 4
    image = image * 255 #scaling the image data up to be between 0-255 to cope with the upper_threshold and lower_threshold parameters
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            #using a nested for loop to access all the pixels in the image
            r = image[i, j, 0] #accessing the red pixels
            g = image[i, j, 1] #accessing the green pixels
            b = image[i, j, 2] #accessing the blue pixels
            if r > upper_threshold and g < lower_threshold and b < lower_threshold:
                #if the rgb values follow the above conditions, means it is a red pixel, so setting the pixel to be white (path required)
                output_image[i,j] = 1
            else:
                #if the rgb values do not follow the above conditions, means it is not a red pixel, so setting the pixel to be black (background)
                output_image[i,j] = 0
    output_image = output_image.astype(np.uint8) #making sure the array contains unsigned integers
    mat_plot.imsave('map-red-pixels.jpg', output_image, cmap = 'gray') #saving the image in the jpg file
    return output_image #returning the numpy array

def find_cyan_pixels(map_filename, upper_threshold = 100, lower_threshold = 50, *args,**kwargs):
    """
    Returns numpy array representing the binary image, and saves the image for the cyan pixels in a jpg file
    :param: map_filename: the filename of the image we want to access
    :param: upper_threshold=100: this is set at 100 unless specified otherwise, used to determine the rgb values
    :param: lower_threshold=50: this is set at 100 unless specified otherwise, used to determine the rgb values
    :return: output_image: binary 2D array numpy of the cyan pixels found
    """
    output_image = np.array #initialising the numpy array to store the output image
    path = './data/' #accessing the path to be able to retrive the map image
    image = mat_plot.imread(path + map_filename) #reading in the image data
    output_image = np.empty([1140, 1053]) #initialising the size of the array to be the same size as the image data array - the image is [1140. 1053, 4] but do not need opaqueness and rgb in a binary image so no 4
    image = image * 255 #scaling the image data up to be between 0-255 to cope with the upper_threshold and lower_threshold parameters
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            #using a nested for loop to access all the pixels in the image
            r = image[i, j, 0] #accessing the red pixels
            g = image[i, j, 1] #accessing the green pixels
            b = image[i, j, 2] #accessing the blue pixels
            if r < lower_threshold and g > upper_threshold and b > upper_threshold:
                #if the rgb values follow the above conditions, means it is a cyan pixel, so setting the pixel to be white (path required)
                output_image[i,j] = 1
            else:
                #if the rgb values do not follow the above conditions, means it is not a cyan pixel, so setting the pixel to be black (background)
                output_image[i,j] = 0
    output_image = output_image.astype(np.uint8) #making sure the array contains unsigned integers
    mat_plot.imsave('map-cyan-pixels.jpg', output_image, cmap = 'gray') #saving the image in the jpg file
    return output_image #returning the numpy array


def detect_connected_components(IMG, *args,**kwargs):
    """
    Reads the image, returns a 2D array, and writes the number of pixels inside each connected component into a text file
    :param: IMG: the image we need to find the connected components within
    :return: MARK: the 2D numpy array containing all the connected components
    """
    MARK = np.zeros([1140, 1053]) #initialising the numpy array with 0's, the same size as IMG
    Q = np.array([]) #initialising an empty numpy array to implement as a queue
    numpixels = [] #2D array which stores the number of pixels each connected component has
    mark = 0 #to index every time a new connected component is found
    for i in range(IMG.shape[0]):
        for j in range(IMG.shape[1]): 
            #iterating through every pixel
            if IMG[i,j] == 1 and MARK[i,j] == 0:
                #if a path has been found, and this hasn't been acknowledged by MARK
                mark = mark + 1 #indexing mark to say a new connected component has been found
                MARK[i,j] = mark #acknowledging that this path has been noticed
                Q = np.append(Q,[[i,j]]) #adding the pixel to the queue to be able to explore the connected paths
                pixels = 0 #to index to calculate the number of pixels within the specified connected component
                while np.size(Q) > 0:
                    #if there are still elements on the path
                    pixels += 1 #with every check of a pixel, adding one
                    #accessing the i and j components from the queue Q, before they are removed below
                    elementi = Q[0]
                    elementj = Q[1]
                    Q = np.delete(Q, 0) #removing the i component from Q
                    Q = np.delete(Q, 0) #removing the j component from Q
                    for s in range(int(elementi)-1, int(elementi)+2):
                        for t in range(int(elementj)-1, int(elementj)+2):
                            if s != elementi or t != elementj:
                                #iterating through all 8 neighbours
                                if s < 1140 and t < 1053: 
                                    #catching any pixels at the edge of the image to not investigate
                                    if IMG[s,t] == 1 and MARK[s,t] == 0:
                                        #adding pixel to the queue and MARK if they have not already been explored
                                        MARK[s,t] = mark
                                        Q = np.append(Q,[s,t])
                numpixels.append(pixels) #adding the number of pixels in the connected component just explored the the array
    #writing the above data to the file
    with open('cc-output-2a.txt', 'w') as file: #creating the file to write the data to
        index = 0 #to index for every new connected component in the file
        for i in numpixels:
            #iterating through all the number of pixels
            index += 1
            #writing all the number of pixels to the file
            file.write("Connection Component " + str(index) + ", number of pixels = " + str(i) + "\n")
        file.write("Total number of connected components = " + str(index)) #writing the total number of connected components
    return MARK #returning the numpy array
##Improvements and Modifications on Algorithm 1:
##Using a variable 'mark' to note the number of connected components, increments by 1 with every new connected component
##Introduced the variable 'pixels' to count the number of pixels within each connected component

def detect_connected_components_sorted(MARK, *args,**kwargs):
    """
    Stores the connected components in a file in decreasing order, and writes the two largest connected components into an image file
    :param: MARK: 2D numpy array containing all the connected components
    :return: nothing as everything is stored in files
    """
    num_pixels = [] #an array to contain the number of pixels of all the connected components
    two_largest = np.zeros([1140, 1053]) #empty 2D numpy array the same size of MARK to store the two largest connected components
    with open('cc-output-2a.txt', 'r') as file: #opening the file containing all the connected components created in the function above
        for line in file:
            #iterating through every line in the file, so every connected component stored in the file
            line = line.strip('\n') 
            numPixels = line.split('=') #splitting the line on = to be able to access the number of pixels
            num_pixels.append(numPixels) #adding each number of pixels to the array num_pixels to be sorted
        #bubble sort
        for i in range(len(num_pixels)-2):
            for j in range(len(num_pixels)-i-2):
                #iterating through the array num_pixels
                #retrieving integer left and right components
                left = int(num_pixels[j][1])
                right = int(num_pixels[j+1][1])
                if right > left:
                    #if values are the wrong way around, swapping them
                    num_pixels[j+1], num_pixels[j] = num_pixels[j], num_pixels[j+1]
    #storing all the sorted connected components in the new file 
    with open('cc-output-2b.txt', 'w') as file: #writing to the file
        for i in range(len(num_pixels)):
            #writing each connected component with their number and number of pixels to the file as each new line
            writing = num_pixels[i][0]
            number = num_pixels[i][1]
            file.write(str(writing) + " = " + str(number) + "\n")
    components = [] #empty array to store the connected component numbers
    #store the top 2 largest connected components in an image file
    with open('cc-output-2b.txt', 'r') as file: #reading the sorted file
        for line in file:
            line = line.replace(",", "") #removing the commas from each line
            component = line.split(" ")
            components.append(component[2]) #component[2] is the number for which connected component it is
        #accessing the number of the longest and second longest connected component
        longest = components[0]
        second_longest = components[1]
    for i in range(MARK.shape[0]):
        for j in range(MARK.shape[1]):
            #iterating through the connected components image
            if MARK[i,j] == int(longest) or MARK[i,j] == int(second_longest):
                #adding the connected component pixels to the two_largest image
                two_largest[i,j] = 1
    two_largest = two_largest.astype(np.uint8) #making sure the array contains unsigned integers
    mat_plot.imsave('cc-top-2.jpg', two_largest, cmap = 'gray') #saving the image in the jpg file