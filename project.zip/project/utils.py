# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification


def sumvalues(values):
    """
    Calculates the sum of the list 'values'
    :param: values: an array needing the sum of its values calculated
    :return: total: the sum of the values
    """  
    total = 0 #variable for storing the sum
    for item in values: #traversing through every item of the list
        if str(item).isnumeric() == True: #checking that the item is numeric
            total = total + item #adding the item to the total
        else:
            #if the item is not an integer, raising an error
           raise TypeError("An integer was not entered") 
    return total #returning the total sum

def maxvalue(values):
    """
    Calculates the index of the maximum value in the list 'values'
    :param: values: an array needing to find its maximum value
    :return: maxI: the index of the maximum value in the array
    """    
    if len(values) == 0:
        #if an empty array is passed in, returning None
        return None
    index = 0 #variable for storing the index of the items in the list
    maxV = values[0] #variable for storing the maximum value in the list - use this to compare the other values
    maxI = None #variable for storing the index of the maximum value - to be returned at the end of the function
    for item in values: #traversing through all the values in the list
        if str(item).isnumeric() == True: #checking that the item is numeric 
            if item > maxV: #if the item is greater than the current max value
                maxV = item #changing the current max value to being the current item
                maxI = index #changing the current max value index to being the index of the current item
        else:
            #if the item is not an integer, raising an error
            raise TypeError("An integer was not entered")
        index += 1 #increasing the index for the next item to be looked at
    return maxI #returning the index of the maximum item

def minvalue(values):
    """
    Calculates the index of the minimum value in the list 'values'
    :param: values: an array needing to find its minimum value
    :return: minI: the index of the minimum value in the array
    """    
    if len(values) == 0:
        #if an empty array is passed in, returning None
        return None
    index = 0 #variable for storing the index of the items in the list
    minV = values[0] #variable for storing the minimum value in the list - use this to compare to the other values
    minI = None #variable for storing the index of the minimum value - to be returned at the end of the function
    for item in values: #traversing through all the values in the list
        if str(item).isnumeric() == True: #checking that the item is numeric
            if item < minV: #if the item is less than the current minimum value 
                minV = item #changing the current minimum value to be the current item
                minI = index #changing the current minimum value index to being the index of the current item
        else:
            #if the item is not an integer, raising an error
            raise TypeError("An integer was not entered")
        index += 1 #increasing the index for the next item to be looked at
    return minI #returning the index of the minimum item

def meannvalue(values):
    """
    Calculates the mean of all the values in the list 'values'
    :param: values: an array needing the mean of its values calculated
    :return: mean: the calculated mean of all the values in the array
    """    
    if len(values) == 0:
        #if an empty array is passed in, returning None
        return None
    num = 0 #variable for storing the number of items in the list
    total = 0 #variable for storing the sum of the items in the list
    for item in values: #traversing through every item in the list
        if str(item).isnumeric() == True: #checking that the item is numeric
            total = total + item #adding the item to the total count
            num += 1 #increasing the number of items by 1
        else:
            #if the item is not an integer, raising an error
            raise TypeError("An integer was not entered")
    mean = total / num #calculating the mean
    return mean #returning the mean

def countvalue(values,xw):
    """
    Calculates the number of occurrences of the value xw in the list 'values'
    :param: values: an array containing values to be compared against the second parameter, xw
    :param: xw: the value to be checked in the array
    :return: occurence: the number of times the value xw appears in the array
    """    
    occurrence = 0 #variable for storing the number of times xw appears in the list
    for item in values: #traversing through every item in the list
        if item == xw: 
            #if the item currently being looked at is the same as the value of xw
            #increasing the value of occurrence by 1, as xw has appeared in the list (again)
            occurrence += 1
    return occurrence #returning the number of occurrences of the value xw